package com.boa.resilience4jdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Resilience4jdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
